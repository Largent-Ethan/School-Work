How to run the program

To compile the program, type the following into the command line:
    gcc --std=gnu99 -o movies movies.c


To run the program, type the following into the command line:
    ./movies <filename>

Replace <filename> with the name of your formatted file. An example file may be called movies_sample_1.csv