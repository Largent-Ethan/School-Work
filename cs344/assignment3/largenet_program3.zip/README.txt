How to run the program

To compile the program, type the following into the command line:
    gcc --std=gnu99 -o smallsh smallsh.c


To run the program, type the following into the command line:
    ./smallsh