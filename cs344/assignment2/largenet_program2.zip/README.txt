How to run the program

To compile the program, type the following into the command line:
    gcc --std=gnu99 -o movies_by_year movies_by_year.c


To run the program, type the following into the command line:
    ./movies_by_year