## How to run

***Encrypting with OpenSSL***

- Put words.txt in the same directory
- Install pycryptodome
  - pip3 install pycryptodome
- Use the command python3 encwssl.py

***

***Weak versus Strong Collision Resistance Property***

- Use the command: python3 wvscolres.py