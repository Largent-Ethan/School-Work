## How to run

- Install qrcode
  - pip install qrcode
- Install pillow
  - pip install pillow
- First, use the following command to generate the qrcode
  - python3 authenticator.py --generate-qr
- Second, use the following command to view the timed otp
  - python3 authenticator.py --get-otp