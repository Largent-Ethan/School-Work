Linked list:
I feel pretty confident I did this right.
I didn't have to look up anything online about them/copy anything.
I think I got all the non-sorting functions figured out.

Primes:
My primes functions is almsot exactly the same as lab, but I added a counter.

Sorting:
I attempted figuring our merge sort out on my own.
I commented out my own two attempts at the bottom of linkedlist.cpp
I ultimately went to geeksforgeeks and followed along to their implementation.
Their implementation had no linked list objects(just nodes),
so I still had to make some changes.
It works! and I somewhat understand how...
If I can't get credit for my sorting functions,
then partial credit for my own failed attempts would be cool,
and if that can't happen I'm fine with getting the 20 points knocked off.